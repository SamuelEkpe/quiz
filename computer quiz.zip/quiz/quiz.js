//Let's set the quiz questions here
const QuizData = [{
        Question: 'What is the sum of 3 and 7',
        a: '37',
        b: '21',
        c: '10',
        d: '4',
        correct: 'c'
    },
    {
        Question: 'Find the average of the following numbers: 2,3,4,5,6,9,12,7',
        a: '20 1/2',
        b: '20',
        c: '6',
        d: '8',
        correct: 'c'

    },
    {
        Question: 'Find the mode of:2,3,4,3,4,5,4,5,3,5,3,6,7',
        a: '3',
        b: '4',
        c: '5',
        d: '2',
        correct: 'a'
    },
    {
        Question: 'What is the product of 4 and 2',
        a: '6',
        b: '8',
        c: '2',
        d: '24',
        correct: 'b'
    }


]; //Questions end here. You can add more.


//We assign the options the constants here for easy accessibility in this js

const aText = document.querySelector('#a_text');
const bText = document.querySelector('#b_text');
const cText = document.querySelector('#c_text');
const dText = document.querySelector('#d_text');
const questionEl = document.querySelector('#question');
const submitBtn = document.querySelector('#submit');
const backBtn = document.querySelector('#back');
const answerEls = document.querySelectorAll('.answer');
const quiz = document.querySelector('#quiz');


//setting global variables for the functions to be used subsequently
let currentQuestion = 0;
let score = 0;
let count = 0;
//function to load the quiz
loadQuiz();

function loadQuiz() {

    deselectAnswers();

    const currentQuizData = QuizData[currentQuestion];
    //To display the questions instead of the html content

    questionEl.innerHTML = currentQuizData.Question;
    aText.innerHTML = currentQuizData.a;
    bText.innerHTML = currentQuizData.b;
    cText.innerHTML = currentQuizData.c;
    dText.innerHTML = currentQuizData.d;




}
//To collect options selected by user 
//Note: User cannot go to the next unless the current question is checked

function getSelected() {
    let answer = undefined;

    answerEls.forEach((answerEl) => {
        // console.log(answer.checked);

        if (answerEl.checked) {
            answer = answerEl.id;
        }
    });
    //To store Answer
    return answer;

}
//Function to disable checked properties
function deselectAnswers() {
    answerEls.forEach((answerEl) => {
        answerEl.checked = false;
    });

}


// click button to fetch next question
submitBtn.addEventListener('click', () => {

    const answer = getSelected();

    console.log(answer);



    //to increment score by number of correct answers 
    if (answer === QuizData[currentQuestion].correct) {
        score = score + 5;
    }
    console.log('You scored ', score, 'points');

    currentQuestion++;

    if (currentQuestion < QuizData.length) {

        loadQuiz();
    } else {

        //To display result
        quiz.innerHTML = `<h3>Congratulations! You scored ${score}%</h3><button  class="reload" onclick="location.reload()">Reload</button>`;

    }



});
backBtn.addEventListener('click', () => {

    answer = getSelected();
    console.log(answer);



    //to increment score by number of correct answers 
    if (answer === QuizData[currentQuestion].correct) {
        score = score;
    }
    console.log('You scored ', score, 'points');

    currentQuestion--;

    if (currentQuestion < QuizData.length) {

        loadQuiz();
    }

});